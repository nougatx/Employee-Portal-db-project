<!DOCTYPE html>
<html>
	<head>
		<title>Employee Database</title>
		<link rel="stylesheet" href="table.css">
	</head>
	<body>
		<h1>Add Department to Employee Database</h1>
		<form action="add_department.php" method="post">
			<input type="text" name="dname" placeholder="Dname">
			<input type="number" name="dnumb" placeholder="Dnumber">
			<input type="number" name="mgr_ssn" placeholder="Mgr_ssn">
            <input type="date" name="mgr_start_date" placeholder="Mgr_start_date">
			<button class = b>Add Department</button>
		</form>
		<form action="index.html">
			<button class = b>Return</button>
		</form>
	</body>
	<?php
		if (isset($_POST['dname']) && isset($_POST['dnumb']) && isset($_POST['mgr_ssn']) && isset($_POST['mgr_start_date'])) {
			$mysqli = new mysqli("localhost", "root", "", "employee_info");
			$sql= 'insert into department values (\''.$_POST["dname"].'\', \''.$_POST["dnumb"].'\', \''.$_POST["mgr_ssn"]. '\', \''.$_POST["mgr_start_date"].'\')';
			$mysqli->query($sql);
			$mysqli->close();
		}
	?>
</html>