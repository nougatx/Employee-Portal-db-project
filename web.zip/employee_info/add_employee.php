<!DOCTYPE html>
<html>
	<head>
		<title>Employee Database</title>
		<link rel="stylesheet" href="table.css">
	</head>
	<body>
		<h1>Add Employee to Employee Database</h1>
		<form action="add_employee.php" method="post">
			<input type="text" name="fname" placeholder="Fname">
			<input type="text" name="minit" placeholder="Minit">
			<input type="text" name="lname" placeholder="Lname">
            <input type="number" name="ssn" placeholder="Ssn">
			<input type="date" name="bdate" placeholder="Bdate">
			<input type="text" name="address" placeholder="Address">
			<input type="text" name="sex" placeholder="Sex">
            <input type="number" name="salary" placeholder="Salary">
			<input type="number" name="super" placeholder="Super_ssn">
			<input type="number" name="dno" placeholder="Dno">
			<button class = b>Add Employee</button>
		</form>
		<form action="index.html">
			<button class = b>Return</button>
		</form>
	</body>
	<?php
		if (isset($_POST['fname']) && isset($_POST['minit']) && isset($_POST['lname']) && isset($_POST['ssn']) && isset($_POST['bdate']) && isset($_POST['address']) && isset($_POST['sex']) && isset($_POST['salary']) && isset($_POST['super']) && isset($_POST['dno'])) {
			$mysqli = new mysqli("localhost", "root", "", "employee_info");
			$sql= 'insert into employee values (\''.$_POST["fname"].'\', \''.$_POST["minit"].'\', \''.$_POST["lname"]. '\', \''.$_POST["ssn"].'\', \''.$_POST["bdate"]. '\', \''.$_POST["address"].'\', \''.$_POST["sex"]. '\', \''.$_POST["salary"].'\', \''.$_POST["super"]. '\', \''.$_POST["dno"].'\')';
            $mysqli->query($sql);
			$mysqli->close();
		}
	?>
</html>