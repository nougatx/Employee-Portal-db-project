<!DOCTYPE html>
<html>
	<head>
		<title>Employee Database</title>
		<link rel="stylesheet" href="table.css">
	</head>
	<body>
		<h1>Add Project to Employee Database</h1>
		<form action="add_project.php" method="post">
			<input type="text" name="pname" placeholder="Pname">
			<input type="number" name="pnumb" placeholder="Pnumber">
			<input type="text" name="plocation" placeholder="Plocation">
            <input type="number" name="dnum" placeholder="Dnum">
			<button class = b>Add Project</button>
		</form>
		<form action="index.html">
			<button class = b>Return</button>
		</form>
	</body>
	<?php
		if (isset($_POST['pname']) && isset($_POST['pnumb']) && isset($_POST['plocation']) && isset($_POST['dnum'])) {
			$mysqli = new mysqli("localhost", "root", "", "employee_info");
			$sql= 'insert into project values (\''.$_POST["pname"].'\', \''.$_POST["pnumb"].'\', \''.$_POST["plocation"]. '\', \''.$_POST["dnum"].'\')';
			$mysqli->query($sql);
			$mysqli->close();
		}
	?>
</html>