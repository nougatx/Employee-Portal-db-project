<!DOCTYPE html>
<html>
	<head>
		<title>Employee Portal</title>
		<link rel="stylesheet" href="table.css">
	</head>
	<body style = "margin: 50px;">
		<h1>Projects in Employee Database</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "", "employee_info");
			$query = "select * from project";
			$result = $mysqli->query($query);
			echo "<table class = center>
			<tr>
			<th>Pname</th>
			<th>Pnumber</th>
			<th>Plocation</th>
			<th>Dnum</th>
			</tr>";
			while ($temp = $result->fetch_assoc()) {
				echo "<tr>";
				foreach ($temp as $key => $value) {
					echo "<td>$value</td>";
				}
				echo "</tr>";
			}
			echo "</table>";
			
			$mysqli->close();
		?>
		<form action="index.html">
			<button class = b>Return</button>
		</form>
	</body>
</html>