<!DOCTYPE html>
<html>
	<head>
		<title>Employee Portal</title>
		<link rel="stylesheet" href="table.css">
	</head>
	<body>
		<h1>Dependents in Employee Database</h1>
        <form action="show_dependents.php" method="post">
			<input type="text" name="name" placeholder="Fname">
			<button class = b>Show Dependent</button>
		</form>
		<?php
			if (isset($_POST['name'])) 
            {
                $mysqli = new mysqli("localhost", "root", "", "employee_info");
                $query = "  select Essn, Dependent_name, d.Sex, d.Bdate, Relationship 
                            from dependent as d, employee 
                            where Essn = Ssn and Fname = '" .$_POST["name"]. "' ";
                $result = $mysqli->query($query);
                echo "<table class = center>
                <tr>
                    <th>Essn</th>
                    <th>Name</th>
                    <th>Sex</th>
                    <th>Bdate</th>
                    <th>Relationship</th>
			    </tr>";
                while ($temp = $result->fetch_assoc()) {
                    echo "<tr>";
                    foreach ($temp as $key => $value) {
                        echo "<td>$value</td>";
                    }
                    echo "</tr>";
                }
                echo "</table>";
                
                $mysqli->close();
            }
		?>
		<form action="index.html">
			<button class = b>Return</button>
		</form>
	</body>
</html>