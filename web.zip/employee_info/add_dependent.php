<!DOCTYPE html>
<html>
	<head>
		<title>Employee Database</title>
		<link rel="stylesheet" href="table.css">
	</head>
	<body>
		<h1>Add Dependent to Employee Database</h1>
		<form action="add_dependent.php" method="post">
			<input type="number" name="essn" placeholder="Essn">
			<input type="text" name="n" placeholder="Dependent_name">
			<input type="text" name="sex" placeholder="Sex">
            <input type="date" name="bdate" placeholder="Bdate">
            <input type="text" name="r" placeholder="Relationship">
			<button class = b>Add Dependent</button>
		</form>
		<form action="index.html">
			<button class = b>Return</button>
		</form>
	</body>
	<?php
		if (isset($_POST['essn']) && isset($_POST['n']) && isset($_POST['sex']) && isset($_POST['bdate']) && isset($_POST['r'])) {
			$mysqli = new mysqli("localhost", "root", "", "employee_info");
			$sql= 'insert into dependent values (\''.$_POST["essn"].'\', \''.$_POST["n"].'\', \''.$_POST["sex"]. '\', \''.$_POST["bdate"]. '\', \''.$_POST["r"].'\')';
			$mysqli->query($sql);
			$mysqli->close();
		}
	?>
</html>