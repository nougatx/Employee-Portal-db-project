<!DOCTYPE html>
<html>
	<head>
		<title>Employee Portal</title>
		<link rel="stylesheet" href="table.css">
	</head>
	<body>
		<h1>Departments in Employee Database</h1>
		<?php
			$mysqli = new mysqli("localhost", "root", "", "employee_info");
			
			$query = "select * from department";
			$result = $mysqli->query($query);
			echo "<table class = center>
			<tr>
			<th>Dname</th>
			<th>Dnumber</th>
			<th>Mgr_ssn</th>
			<th>Mgr_start_date</th>
			</tr>";
			while ($temp = $result->fetch_assoc()) {
				echo "<tr>";
				foreach ($temp as $key => $value) {
					echo "<td>$value</td>";
				}
				echo "</tr>";
			}
			echo "</table>";
			
			$mysqli->close();
		?>
		<form action="index.html">
			<button class = b>Return</button>
		</form>
	</body>
</html>